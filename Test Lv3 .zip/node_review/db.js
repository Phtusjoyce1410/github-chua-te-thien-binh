const { MongoClient } = require("mongodb");

const db = {};

const connectToDb = () => {
  const client = new MongoClient("mongodb://localhost:27017");
  client.connect(() => {
    const database = client.db("TuFuture140.testlv3");
    db.inventories = database.collection("inventories");
    db.orders = database.collection("orders");
    db.users = database.collection("users");

    // Import inventory data
    const inventoryData = [
      { _id: 1, sku: "almonds", description: "product 1", instock: 120 },
      { _id: 2, sku: "bread", description: "product 2", instock: 80 },
      { _id: 3, sku: "cashews", description: "product 3", instock: 60 },
      { _id: 4, sku: "pecans", description: "product 4", instock: 70 },
    ];

    db.inventories.insertMany(inventoryData, (err, result) => {
      if (err) {
        console.error("Error importing inventory data:", err);
      } else {
        console.log("Inventory data imported successfully");
      }
    });

    // Import order data
    const orderData = [
      { _id: 1, item: "almonds", price: 12, quantity: 2 },
      { _id: 2, item: "pecans", price: 20, quantity: 1 },
      { _id: 3, item: "pecans", price: 20, quantity: 3 },
    ];

    db.orders.insertMany(orderData, (err, result) => {
      if (err) {
        console.error("Error importing order data:", err);
      } else {
        console.log("Order data imported successfully");
      }
    });
  });
};

module.exports = { connectToDb, db };

